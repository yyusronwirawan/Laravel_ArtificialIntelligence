<?php

return [

    'connections' => [

        'locations' => [
            'driver' => 'sqlite',
            'database' => storage_path('amamarul-locations/locations.sqlite'),
            'prefix' => '',
        ],
    ]
];
